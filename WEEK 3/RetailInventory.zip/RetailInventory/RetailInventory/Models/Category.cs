﻿namespace RetailInventory.Models
{
    public class Category
    {
        public int Id { get; set; }            // Primary key
        public required string Name { get; set; }       // Category name 
        public List<Product> Products { get; set; } = new();  // Navigation property 
    }
}