﻿using Microsoft.EntityFrameworkCore;
using RetailInventory.Data;
using RetailInventory.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RetailInventory.Services
{
    public class ProductService
    {
        private readonly AppDbContext _context;

        public ProductService(AppDbContext context)
        {
            _context = context;
        }
        // Retrieve all products
        public async Task<List<Product>> GetAllProductsAsync()
        {
            return await _context.Products.Include(p => p.Category).ToListAsync();
        }
        // Find product by ID
        public async Task<Product> GetProductByIdAsync(int id)
        {
            return await _context.Products.Include(p => p.Category).FirstOrDefaultAsync(p => p.Id == id);
        }

        // Find the first product that is more expensive than the given threshold
        public async Task<Product> GetExpensiveProductAsync(decimal priceThreshold)
        {
            return await _context.Products
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.Price > priceThreshold);
        }
    }
}
