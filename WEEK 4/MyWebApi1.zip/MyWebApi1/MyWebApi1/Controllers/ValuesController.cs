﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace MyWebApi1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private static List<string> values = new List<string> { "Value1", "Value2" };

        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return Ok(values); 
        }

        // POST api/values
        [HttpPost]
        public ActionResult Post([FromBody] string value)
        {
            values.Add(value); 
            return CreatedAtAction(nameof(Get), new { id = values.Count - 1 }, value); 
        }
    }
}
