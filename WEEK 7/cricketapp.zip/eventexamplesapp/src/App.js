import logo from './logo.svg';
import './App.css';
import React, {useState} from 'react';

function App() {
  const [counter, setCounter] = useState(0);
  const [rupees, setRupees] = useState('');
  const [euros, setEuros] = useState('');

  const increment = () => {
    setCounter(counter + 1);
    console.log("Hello, this is a static message.");
  };

  const decrement = () => {
    setCounter(counter - 1);
  };

  const sayWelcome = (message) => {
    console.log(message);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const conversionRate = 0.012; // Example conversion rate
    setEuros(rupees * conversionRate);
  };
  
  return (
    <div>
      <h1>Event Handling Example</h1>
      <h2>Counter: {counter}</h2>
      <button onClick={increment}>Increment</button>
      <button onClick={decrement}>Decrement</button>
      <button onClick={() => sayWelcome("Welcome")}>Say Welcome</button>
      <button onClick={() => alert("I was clicked")}>OnPress</button>

      <h2>Currency Converter</h2>
      <form onSubmit={handleSubmit}>
        <input
        type="number"
        value={rupees}
        onChange={(e) => setRupees(e.target.value)}
        placeholder="Enter amount in Rupees"
        />
        <button type="submit">Convert to Euro</button>
        </form>
        {euros && <h3>Converted Amount: {euros} Euros</h3>}
    </div>
    );
  }

export default App;
   