﻿namespace MyWebApi4.Models
{
    public static class EmployeeRepository
    {
        public static List<Employee> Employees = new List<Employee>
        {
            new Employee { Id = 1, Name = "Alice", Position = "Developer", Salary = 60000 },
            new Employee { Id = 2, Name = "Bob", Position = "Manager", Salary = 80000 }
        };
    }
}
