using NUnit.Framework; // Ensure you have this using directive
using CalcLibrary; // Import the namespace of the parent project

namespace CalculatorTest
{
    [TestFixture]
    public class CalculatorTests
    {
        private SimpleCalculator _calculator;

        [SetUp]
        public void SetUp()
        {
            _calculator = new SimpleCalculator();
        }

        [TestCase(3,4,7)]
        public void Add_ShouldReturnCorrectSum(int a, int b, int expected)
        {
            // Act
            var result = _calculator.Addition(a, b);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }

        [TestCase(10,4,6)]
        public void Subtract_ShouldReturnCorrectDifference(int a, int b, int expected)
        {
            // Act
            var result = _calculator.Subtraction(a, b);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }

        [TestCase(12,2,24)]
        public void Multiply_ShouldReturnCorrectProduct(int a, int b, int expected)
        {
            // Act
            var result = _calculator.Multiplication(a, b);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }

        [TestCase(6,3,2)]
        public void Divide_ShouldReturnCorrectQuotient(int a, int b, int expected)
        {
            // Act
            var result = _calculator.Division(a, b);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }
    }
}
