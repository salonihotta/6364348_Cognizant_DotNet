﻿using Microsoft.AspNetCore.Mvc;
namespace MyWebApi2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private static List<string> employees = new List<string>
        {
            "Alex Volkav",
            "Rhys Larsen",
            "Dante Russo"
        };
        // GET: api/employees
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<string>> Get()
        {
            return Ok(employees);
        }
        // POST: api/employees
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult Post([FromBody] string value)
        {
            if (string.IsNullOrEmpty(value))
                return BadRequest();

            employees.Add(value);
            return CreatedAtAction(nameof(Get), new { id = employees.Count - 1 }, value);
        }

        // Named endpoint demonstration
        [HttpGet("search")]
        [ActionName("SearchEmployees")]
        public ActionResult<IEnumerable<string>> Search(string query)
        {
            var results = employees.Where(e => e.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
            return Ok(results);
        }
    }
}
