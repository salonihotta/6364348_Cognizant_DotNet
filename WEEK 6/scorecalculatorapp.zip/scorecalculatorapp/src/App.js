//import logo from './logo.svg';
//import './App.css';
import { CalculateScore } from '../src/Components/CalculateScore';

function App() {
  return (
    <div>
      <CalculateScore Name={"Saloni"}
      School={"DAV Public School"}
      total={287}
      goal={3} />
    </div>
  );
}

export default App;
