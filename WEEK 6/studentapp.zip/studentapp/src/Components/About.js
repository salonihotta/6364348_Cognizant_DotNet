import React from 'react';
function About() {
  return (
  <div>
    <h1>Welcome to the About page of the Student Management Portal</h1>
  </div>
  );
}

export default About;
     