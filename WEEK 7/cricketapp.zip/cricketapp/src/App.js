//import logo from './logo.svg';
//import './App.css';
import React from 'react';
import ReactDOM from 'react-dom';
import ListofPlayers from './Components/ListofPlayers';
import IndianPlayers from './Components/IndianPlayers';

const App = () => {
    const flag = true; 
    return (
        <div>
            {flag ? (
                <>
                    <ListofPlayers />
                    <IndianPlayers />
                </>
            ) : (
                <h2>No Players to Display</h2>
            )}
        </div>
    );
};

export default App;