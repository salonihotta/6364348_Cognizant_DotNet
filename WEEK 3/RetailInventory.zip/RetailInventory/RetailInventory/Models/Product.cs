﻿namespace RetailInventory.Models
{
    public class Product
    {
        public int Id { get; set; }            // Primary key
        public required string Name { get; set; }       // Product name 
        public decimal Price { get; set; }     // Price
        public int CategoryId { get; set; }    // Foreign key
        public Category? Category { get; set; } // Navigation property 
    }
}
