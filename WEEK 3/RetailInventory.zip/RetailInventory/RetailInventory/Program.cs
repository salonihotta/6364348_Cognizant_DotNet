﻿using Microsoft.EntityFrameworkCore;
using RetailInventory.Data;
using RetailInventory.Models;
using RetailInventory.Services;
class Program
{
    static async Task Main(string[] args)
    {
        using var db = new AppDbContext();
        await db.Database.MigrateAsync();

        await AddSampleDataAsync(db);
        await DisplayDataAsync(db);
    }

    static async Task AddSampleDataAsync(AppDbContext db)
    {
        if (await db.Categories.AnyAsync()) return;

        var electronics = new Category { Name = "Electronics" };
        var groceries = new Category { Name = "Groceries" };

        await db.Categories.AddRangeAsync(electronics, groceries);
        await db.SaveChangesAsync();

        await db.Products.AddRangeAsync(
            new Product { Name = "Smartphone", Price = 699.99m, CategoryId = electronics.Id },
            new Product { Name = "Laptop", Price = 12999.99m, CategoryId = electronics.Id }, // Corrected price
            new Product { Name = "Apple", Price = 0.99m, CategoryId = groceries.Id }
        );

        await db.SaveChangesAsync();
    }
    static async Task DisplayDataAsync(AppDbContext db)
    {
        var products = await db.Products.Include(p => p.Category).ToListAsync();
        Console.WriteLine("Products in Inventory:");
        foreach (var p in products)
        {
            Console.WriteLine($"- {p.Name} ({p.Category.Name}): ${p.Price}");
        }

        // Additional Lab 5 retrieval logic
        var productService = new ProductService(db);

        // 1. Retrieve all products
        var allProducts = await productService.GetAllProductsAsync();
        Console.WriteLine("\nAll Products:");
        foreach (var p in allProducts)
        {
            Console.WriteLine($"{p.Name} - ${p.Price}");
        }

        // 2. Find by ID
        var product = await productService.GetProductByIdAsync(1);
        Console.WriteLine($"\nFound: {product?.Name}");

        // 3. FirstOrDefault with condition
        var expensive = await productService.GetExpensiveProductAsync(11000);
        Console.WriteLine($"Expensive: {expensive?.Name}");
        
    }
}
