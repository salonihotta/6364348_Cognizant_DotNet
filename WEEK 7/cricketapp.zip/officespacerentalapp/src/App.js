import logo from './logo.svg';
import './App.css';
import React from 'react';
const offices = [
  { name: 'Office A', rent: 50000, address: '123 Main St' },
  { name: 'Office B', rent: 70000, address: '456 Elm St' },
  { name: 'Office C', rent: 60000, address: '789 Oak St' },
];
function App() {
  return (
    <div className="App">
      {/* Heading of the page */}
      <h1>Office Space Rental App</h1>
      
      {/* Image of the office space */}
      <img src="office-image.jpg" alt="Office Space" />
      
      {/* List of offices */}
      <ul>
        {offices.map((office, index) => (
          <li key={index}>
            <h2>{office.name}</h2>
            {/* Display rent with conditional styling */}
            <p style={{ color: office.rent < 60000 ? 'red' : 'green' }}>
              Rent: ${office.rent}
            </p>
            <p>Address: {office.address}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
