import React from 'react';

const IndianPlayers = () => {
    const T20players = ['Player A', 'Player B', 'Player C'];
    const RanjiTrophyPlayers = ['Player D', 'Player E', 'Player F'];

    const mergedPlayers = [...T20players, ...RanjiTrophyPlayers];

    const oddPlayers = mergedPlayers.filter((_, index) => index % 2 !== 0);
    const evenPlayers = mergedPlayers.filter((_, index) => index % 2 === 0);
    return (
        <div>
            <h2>Odd Team Players</h2>
            <ul>
                {oddPlayers.map(player => (
                    <li key={player}>{player}</li>
                ))}
            </ul>
            <h2>Even Team Players</h2>
            <ul>
                {evenPlayers.map(player => (
                    <li key={player}>{player}</li>
                ))}
            </ul>
        </div>
    );
};

export default IndianPlayers;
