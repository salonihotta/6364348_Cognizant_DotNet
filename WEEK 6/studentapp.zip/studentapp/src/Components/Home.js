import React from 'react';
function Home() {
    return (
    <div>
        <h1>Welcome to the Home page of the Student Management Portal</h1>
    </div>
    );
}
export default Home;
     