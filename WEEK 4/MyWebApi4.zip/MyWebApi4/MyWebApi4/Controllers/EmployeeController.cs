﻿using Microsoft.AspNetCore.Mvc;
using MyWebApi4.Models;

namespace MyWebApi4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        [HttpPut("{id}")]
        public ActionResult<Employee> UpdateEmployee(int id, [FromBody] Employee updatedEmployee)
        {
            if (id <= 0)
                return BadRequest("Invalid employee id");

            var employee = EmployeeRepository.Employees.FirstOrDefault(e => e.Id == id);
            if (employee == null)
                return BadRequest("Employee not found");

            // Update fields
            employee.Name = updatedEmployee.Name ?? employee.Name;
            employee.Position = updatedEmployee.Position ?? employee.Position;
            employee.Salary = updatedEmployee.Salary;

            return Ok(employee);
        }
    }
}
